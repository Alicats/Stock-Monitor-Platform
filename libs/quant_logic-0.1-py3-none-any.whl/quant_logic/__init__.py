# quant_logic/__init__.py
from .calculation import calculate_stock_dividend