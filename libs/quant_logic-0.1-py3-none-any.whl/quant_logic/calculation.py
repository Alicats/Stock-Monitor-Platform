# quant_logic/calculation.py
import akshare as ak
import re


# 计算股票的股息率(TTM)
def calculate_stock_dividend(symbol: str):
    try:
        print(f"  开始计算股票 {symbol} 股息率(TTM)...")
        target_symbol = symbol.split('.')[1] + symbol.split('.')[0]  
        stock_individual_spot_xq_df = ak.stock_individual_spot_xq(symbol=target_symbol)
        dividend = stock_individual_spot_xq_df.loc[stock_individual_spot_xq_df['item'] == '股息率(TTM)', 'value'].values[0]
        print(f"  股票 {symbol} 股息率(TTM): {dividend}")
        return dividend
    except Exception as e:
        print(f"Error {symbol}: {e}"); return 0.0



# 计算ETF的股息率(TTM)
def calculate_etf_dividend(symbol: str):
    
    def extract_dividend(value):
        match = re.search(r"(\d+\.?\d*)", value)
        return float(match.group(1)) if match else 0.0

    try:
        print(f"  开始计算ETF {symbol} 股息率(TTM)...")
        clean_symbol = symbol.split('.')[0]
        hongli_jing_em_df = ak.fund_open_fund_info_em(symbol=clean_symbol, indicator="单位净值走势")
        latest_net_value = hongli_jing_em_df.tail(1)['单位净值'].values[0]
        hongli_fenhong_em_df = ak.fund_open_fund_info_em(symbol=clean_symbol, indicator="分红送配详情")
        total_dividend = hongli_fenhong_em_df.head(12)["每份分红"].apply(extract_dividend).sum()
        dividend = round((total_dividend / latest_net_value) * 100, 4)
        print(f"  ETF {symbol} 股息率(TTM): {dividend}")
        return dividend
    except Exception as e:
        print(f"Error {symbol}: {e}"); return 0.0



    